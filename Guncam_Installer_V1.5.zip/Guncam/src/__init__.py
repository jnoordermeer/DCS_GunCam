"""
DCS GunCam package
""" 